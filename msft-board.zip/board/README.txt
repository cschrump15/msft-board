MSFT WEEKLY BOARD - HOW TO PUT IT ON VERCEL
===========================================
What's here
  index.html     the board (the website)
  api/board.js   small server function: checks the team passcode and saves to the database
  package.json   needed by Vercel, nothing to edit

STEP 1 - Put the files on GitHub (easiest path)
  1. Make a free GitHub account if you don't have one, then create a NEW PRIVATE repository
     (name it anything, e.g. msft-board).
  2. Upload this folder's contents (index.html, package.json, and the api folder) using
     "Add file > Upload files". Keep the folder structure: api/board.js.

STEP 2 - Create the site on Vercel
  1. Log in to vercel.com (you can sign in with GitHub).
  2. Add New > Project > pick your repository > Deploy. No settings need changing.

STEP 3 - Add the free database (Redis)
  1. In your Vercel project, open the Storage tab (or Marketplace) and add "Upstash Redis"
     on the free plan. Connect it to this project when asked.
     This adds the database connection settings for you automatically.
  (Menu names on Vercel change from time to time. If you don't see them, search the dashboard for "Upstash".)

STEP 4 - Set the team passcode
  1. Project > Settings > Environment Variables.
  2. Add a variable named  TEAM_PASSCODE  with the passcode you want your team to use. Save.

STEP 5 - Redeploy
  1. Deployments tab > the latest deployment > ... > Redeploy.
  2. Open your site's link, enter the passcode, and you're in. Share the link and passcode with your team.

NOTES
  - Anyone with the link AND the passcode can view and edit. To lock everyone out and re-issue a new
    passcode, change TEAM_PASSCODE in Vercel and redeploy.
  - The page re-syncs with the database about every 8 seconds, so people see each other's changes shortly after they happen.
  - Reset week clears checkmarks, notes, due times and the Week-of box, and un-assigns the Ana and Staff "X1" tasks.
    Marcus and Chris tasks go back to Marcus and Chris. Project names, steps and the people list are kept.
  - Before first use: ask IT whether project codes and schedule dates may be kept on outside services (Vercel / Upstash).
